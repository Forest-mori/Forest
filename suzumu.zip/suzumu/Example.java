package forest;


public class Example extends Object
{
	public static void main(String args[])
	{
		ForestModel aModel = new ForestModel();
		return;
	}
}